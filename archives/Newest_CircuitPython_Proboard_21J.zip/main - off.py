import time
import board
import neopixel
led = neopixel.NeoPixel(board.NEOPIXEL, 1)
led[0] = (0, 0, 0) # Set the NeoPixel dark. It still consumes current.
while True:
    time.sleep(1)
    