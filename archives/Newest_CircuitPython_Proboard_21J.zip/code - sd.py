import time
import board
import busio
import digitalio
import neopixel
led = neopixel.NeoPixel(board.NEOPIXEL, 1)
cs = digitalio.DigitalInOut(board.D11) # SPI Chip Select
cd = digitalio.DigitalInOut(board.D12) # SD Card Detect
cd.direction = digitalio.Direction.INPUT
cd.pull = digitalio.Pull.UP
present = not cd.value

if present==True:
    import adafruit_sdcard
    import storage
    spi = busio.SPI(board.SCK, MOSI=board.MOSI, MISO=board.MISO)
    sdcard = adafruit_sdcard.SDCard(spi, cs)
    vfs = storage.VfsFat(sdcard)
    storage.mount(vfs, "/sd")
    with open("/sd/Test.txt", "a") as f:
        f.write("Test program ran successfully.\r\n")
    led[0] = (0, 1, 0) # Green light means SD card is inserted.
else:
    led[0] = (1, 0, 0) # Red light means SD card is not inserted.

while True:
    time.sleep(1)

    